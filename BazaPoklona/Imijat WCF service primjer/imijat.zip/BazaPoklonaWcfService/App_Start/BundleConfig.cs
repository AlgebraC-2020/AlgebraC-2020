﻿using System.Web;
using System.Web.Optimization;

namespace BazaPoklonaWcfService
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            var cdnPath = "http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.7.1.min.js";
            var jqval = "https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js";
            var moder = "https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js";
            var bootstr = "https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js";



            bundles.Add(new ScriptBundle("~/Content/jquery", cdnPath).Include(
                        "~/Content/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/Content/jqueryval", jqval).Include(
                        "~/Content/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/Content/modernizr", moder).Include(
                        "~/Content/modernizr-*"));

            bundles.Add(new ScriptBundle("~/Content/bootstrap", bootstr).Include(
                      "~/Content/bootstrap.js"));
            /*
            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css"));
            */
        }
    }
}
